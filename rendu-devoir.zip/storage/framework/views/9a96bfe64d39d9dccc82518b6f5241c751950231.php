<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>