<?php $__env->startSection('homeContent'); ?>
    <h6><a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">Création d'un utilisateur</a></h6>
    <table class="table table-sm table-hover">
        <thead>
        <tr>
            <td class="text-center">Prenom et Nom</td>
            <td class="text-center">Email</td>
            <td class="text-center">Role</td>
            <td class="text-center">formation</td>
            <td class="text-center">Modification</td>
            <td class="text-center" colspan="2">Actions</td>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($user->prenom); ?> <?php echo e($user->nom); ?></td>
                <td><?php echo e($user->adresse_mel); ?></td>
                <td><?php echo e($user->role); ?></td>
                <td><?php echo e($user->formation['nom_formation']); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary">
                        <i class="fa fa-edit"></i>
                    </a>
                </td>
                <td>
                    <?php if($user->status == \App\Enum\StatusUser::LOCKED): ?>
                        <form method="post" action="<?php echo e(route('admin.users.unlock', $user)); ?>">
                            <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


                            <button type="submit" class="btn btn-danger" title="Débloquer l'utilisateur">
                                <i class="fa fa-lock"></i>
                            </button>
                        </form>
                    <?php endif; ?>

                    <?php if($user->status == \App\Enum\StatusUser::UNLOCKED): ?>
                        <form method="post" action="<?php echo e(route('admin.users.lock', $user)); ?>">
                            <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


                            <button type="submit" class="btn btn-success" title="Bloquer l'utilisateur">
                                <i class="fa fa-unlock"></i>
                            </button>
                        </form>
                    <?php endif; ?>

                    <form method="post" action="<?php echo e(route('admin.users.reset', $user)); ?>">
                        <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


                        <button type="submit" class="btn btn-warning" title="Réinitialiser mot de pass de l'utilisateur">
                            <i class="fa fa-warning"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/users/index.blade.php ENDPATH**/ ?>