<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="list-group-item list-group-item-action
                    <?php echo e(setActiveRoot('admin.users.index')); ?>">
                    <?php echo e(__('Gestion des utilisateurs')); ?>

                </a>

                <a href="<?php echo e(route('admin.matiere.index')); ?>" class="list-group-item list-group-item-action
                    <?php echo e(setActiveRoot('admin.matiere.index')); ?>">
                    <?php echo e(__('Gestion des matières')); ?>

                </a>

                <a href="<?php echo e(route('admin.formations.index')); ?>" class="list-group-item list-group-item-action
                    <?php echo e(setActiveRoot('admin.formations.index')); ?>">
                    <?php echo e(__('Gestion des formations')); ?>

                </a>

                <a href="<?php echo e(route('admin.approb.create')); ?>" class="list-group-item list-group-item-action
                    <?php echo e(setActiveRoot('admin.approb.create')); ?>">
                    <?php echo e(__('Approbation des demandes')); ?>

                </a>
            </div>
        </div>

        <div class="col-md-9">
            <?php echo $__env->yieldContent('homeContent'); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.new.base', ['title' => 'Administration'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/home/index.blade.php ENDPATH**/ ?>