<?php $__env->startComponent('mail::message'); ?>
# Introduction

# Hello <?php echo e($user->prenom); ?> <?php echo e($user->nom); ?>


# votre compte a été créer sur http://www.rendudevoir-upicardie.com/login sous les infos:
    - Login: <?php echo e($user->adresse_mel); ?>

    - Password: <?php echo e($random); ?>


Merci de changer votre mot de passe a la première connexion.

Cordialement.<br>

<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/emails/users/sender.blade.php ENDPATH**/ ?>