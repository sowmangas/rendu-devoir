<?php $__env->startSection('homeContent'); ?>
    <h1>Formulaire d'une matière</h1>
    <form action="<?php echo e(route('admin.matiere.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label for="nom_matiere" class="sr-only">Nom de la matiere</label>
            <input type="text" name="nom_matiere" id="nom_matiere" class="form-control
                       <?php echo e($errors->has('nom_matiere') ? ' is-invalid' : ''); ?>"
                   placeholder="Saisissez le nom de la matière" value="<?php echo e(old('nom_matiere')); ?>">

            <?php if($errors->has('nom_matiere')): ?>
                <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nom_formation')); ?></strong>
                        </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-primary">Sauvegarder</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/matiere/create.blade.php ENDPATH**/ ?>