<?php $__env->startSection('content'); ?>
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100 p-t-19 p-b-30">
                <form class="login100-form validate-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>

                    <div class="login100-form-avatar"><img src="<?php echo e(asset('images/logo-upjv-bleu.png')); ?>" alt=""></div>

                    <span class="login100-form-title p-t-20 p-b-45">Identifiez-vous</span>

                    <div class="wrap-input100 validate-input m-b-10<?php echo e($errors->has('adresse_mel') ? ' alert-validate' : ''); ?>"
                         data-validate="<?php if($errors->has('adresse_mel')): ?><?php echo e($errors->first('adresse_mel')); ?><?php endif; ?>">
                        <label for="email" class="sr-only"></label>
                        <input id="email" class="input100" type="text" name="adresse_mel" value="<?php echo e(old('adresse_mel')); ?>" placeholder="Nom d'utilisateur" autofocus>
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-user"></i>
                        </span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-10<?php echo e($errors->has('password') ? ' alert-validate' : ''); ?>"
                         data-validate="<?php if($errors->has('password')): ?><?php echo e($errors->first('password')); ?><?php endif; ?>">
                        <label for="password" class="sr-only"></label>
                        <input class="input100<?php echo e($errors->has('password') ? ' alert-validate' : ''); ?>" type="password" id="password" name="password" placeholder="Mot de pass">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-lock"></i>
                        </span>
                    </div>

                    <div class="container-login100-form-btn p-t-10">
                        <button class="login100-form-btn">Connexion</button>
                    </div>

                </form>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['title' => 'Login'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/auth/login.blade.php ENDPATH**/ ?>