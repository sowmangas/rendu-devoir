<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="offset-2 col-md-8">
            <h1>Formulaire de creation d'un devoir</h1>
            <form action="<?php echo e(route('prof.devoirs.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="formation_id" class="sr-only">Formation</label>
                    <select type="text" name="formation_id" id="formation_id" class="form-control ">
                        <option disabled selected>Selectionner une formation</option>
                        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(old('formation_id') ?: $formation->id); ?>">
                                <?php echo e($formation->nom_formation); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group" data-validate="Champ obligatoire">
                    <label for="nom_matiere" class="sr-only">Nom de la matiere</label>
                    <select id="nom_matiere" class="form-control" name="nom_matiere">
                        <option value="Choisir la matière" disabled selected>Choisir la matière</option>
                        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($matiere->nom_matiere); ?>"><?php echo e($matiere->nom_matiere); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        </span>
                    <?php if($errors->has('matiere')): ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('matiere')); ?></strong>
                            </span>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="intitule" class="sr-only">Nom de la formation</label>
                    <input type="text" name="intitule" id="intitule" class="form-control"
                           placeholder="Saisissez l'intitulé du devoir" value="<?php echo e(old('intitule')); ?>">
                </div>

                <div class="form-group">
                    <label for="evaluer" class="form-check-inline">
                        Cocher si dévoir évalué
                        <input type="checkbox" name="evaluer" id="evaluer" class="form-control -align-left">
                    </label>

                </div>

                <div class="form-group" data-validate="Champ obligatoire">
                    <label for="type_correction" class="sr-only">Type de la correction</label>
                    <select id="type_correction" class="form-control" name="type_correction">
                        <option value="" disabled selected>Choisir le type de la correction</option>
                        <option value=1>Corrigé type</option>
                        <option value=0>Pas de corrigé type</option>
                    </select>
                    <span class="focus-input100"></span>
                    <span class="symbol-input100">
                        </span>
                    <?php if($errors->has('type_correction')): ?>
                        <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('type_correction')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="form-group" id="corrige_input" style="display: none;">
                    <label for="corrige_type">Selectionner le corrigé type <i>La taille maximal du fichier est de
                            2MB</i></label>
                    <input type="file" name="corrige_type" id="corrige_type" class="form-control form-control-sm"
                           value="<?php echo e(old('corrige_type')); ?>">
                </div>

                <div class="form-group">
                    <label for="date_limit_depot">Date limite</label>
                    <input type="date" name="date_limit_depot" id="date_limit_depot" class="form-control"
                           placeholder="Saisissez le nom de la formation" value="<?php echo e(old('date_limit_depot')); ?>">
                </div>

                <div class="form-group">
                    <label for="enonce">Selectionner l'énoncé <i>La taille maximal du fichier est de 2MB</i></label>
                    <input type="file" name="enonce" id="enonce" class="form-control" value="<?php echo e(old('enonce')); ?>">
                </div>

                <div class="form-group">
                    <label for="periode" class="sr-only">Semestre de formation</label>
                    <select name="periode" id="periode" class="form-control">
                        <option disabled selected value="">Choisir le semestre</option>
                        <option value="S1-<?php echo e(now()->year); ?>">Semestre 1</option>
                        <option value="S2-<?php echo e(now()->year); ?>">Semestre 2</option>
                    </select>
                </div>



                <div class="form-group">
                    <button type="submit" class="btn btn-outline-primary">Sauvegarder</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

    <script>

        $("#type_correction").change(function(){
            var selectedTypeCorrection = $(this).children("option:selected").val();
            if (selectedTypeCorrection ==1) {
                $('#corrige_input').show()
            }
            else {
                $('#corrige_input').hide()
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', ['title' => 'Création devoir'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/prof/devoir/create.blade.php */ ?>