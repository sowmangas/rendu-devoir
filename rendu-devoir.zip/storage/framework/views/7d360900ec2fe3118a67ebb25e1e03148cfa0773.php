<?php $__env->startSection('homeContent'); ?>
    <h1>Formulaire d' approbation</h1>
    <form action="<?php echo e(route('admin.formations.store')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <div class="form-group">
            <label for="nom_formation" class="sr-only">Nom de la formation</label>
            <input type="text" name="nom_formation" id="nom_formation" class="form-control
                       <?php echo e($errors->has('nom_formation') ? ' is-invalid' : ''); ?>"
                   placeholder="Saisissez le nom de la formation" value="<?php echo e(old('nom_formation')); ?>">

            <?php if($errors->has('nom_formation')): ?>
                <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('nom_formation')); ?></strong>
                        </span>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <button type="submit" class="btn btn-outline-primary">Sauvegarder</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/approbation/show.blade.php */ ?>