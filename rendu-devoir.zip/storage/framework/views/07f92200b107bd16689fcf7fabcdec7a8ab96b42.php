<?php $__env->startSection('content'); ?>
    <h1>Formulaire de creation d'un rendu</h1>

    <div class="row">
        <div class="offset-2 col-md-8">
            <form action="<?php echo e(route('etudiant.rendus.store')); ?>" enctype="multipart/form-data" method="post">
                <?php echo e(csrf_field()); ?>


                <div class="form-group">
                    <label for="devoir_id">Formation</label>
                    <select type="text" name="devoir_id" id="devoir_id" class="form-control">
                        <option disabled selected>Selectionner le devoir</option>
                        <?php $__currentLoopData = $devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(old('devoir_id') ?: $devoir->id); ?>">
                                <?php echo e($devoir->intitule); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="rendu">Selectionner le devoir à rendre <i>La taille maximal du fichier est de 2MB</i></label>
                    <input type="file" name="rendu" id="rendu" class="form-control" value="<?php echo e(old('rendu')); ?>">
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-outline-primary">Sauvegarder</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/etudiant/rendu/create.blade.php */ ?>