<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(!$devoir->visible_corrige_type): ?>
                <form action="<?php echo e(route('prof.devoirs.putVisible', $devoir)); ?>" method="post"
                      onsubmit="return confirm('Vous êtes sur le point d\'afficher le corrigé type. l\'opération est irreversible. \n Êtes-vous sûr ?')">
                    <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>

                    <button type="submit" class="btn btn-primary btn-sm">Afficher corrigé type</button>
                </form>
            <?php endif; ?>

            <form action="<?php echo e(route('prof.rendus.update', $devoir)); ?>" method="post"
                  onsubmit="return confirm('Vous êtes sur le point de corriger un devoir, \n l\'opération est irreversible.\n Êtes-vous sûr ?')">
                <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


                <table class="table table-sm table-hover">
                    <thead>
                    <tr>
                        <th class="text-center">Intitulé</th>
                        <th class="text-center">Période</th>
                        <th class="text-center">Note</th>
                        <th class="text-center">Commentaires</th>
                        <th class="text-center">Rendu</th>
                        <th class="text-center">Date de dépôt</th>
                        <th class="text-center" colspan="2">Options</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $devoir->rendus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rendu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="text-center">
                            <td><?php echo e($devoir->intitule); ?></td>
                            <td><?php echo e($devoir->periode); ?></td>
                            <td>
                                <label for="note" class="sr-only"></label>
                                <input type="text" name="note" id="note" class="form-control form-control-sm"
                                       placeholder="Saisir la note de l'étudiant" value="<?php echo e($rendu->note); ?>"
                                    <?php echo e($rendu->note ? 'disabled' : ''); ?>>
                                <label for="note" class="sr-only"></label>
                                <input type="hidden" name="etudiant_id" value="<?php echo e($rendu->user_id); ?>">
                            </td>
                            <td>
                                <label for="commentaire" class="sr-only"></label>
                                <textarea name="commentaire" id="commentaire" cols="30" rows="5"
                                          <?php echo e($rendu->commentaire ? 'disabled' : ''); ?> class="form-control form-control-sm"
                                          placeholder="Saisir un commentaire"><?php echo e($rendu->commentaire); ?></textarea>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(asset($rendu->rendu)); ?>" download class="btn btn-link"
                                   title="Téléchargé le rendu">
                                    <i class="fa fa-download"></i>
                                </a>
                            </td>
                            <td class="text-center"><?php echo e($rendu->created_at->format('d/m/Y')); ?></td>
                            <td class="text-center">
                                <button type="submit" class="btn btn-outline-primary btn-sm"
                                    <?php echo e(($rendu->note && $rendu->commentaire) ? 'disabled' : ''); ?>>
                                    Corriger
                                </button>
                            </td>
                            <td class="text-center">
                                <?php if($rendu->note): ?>
                                    <update-note-component
                                        url="<?php echo e(route('prof.modification.note')); ?>"
                                        csrf="<?php echo e(csrf_token()); ?>"
                                        :userid="<?php echo e(Auth::id()); ?>"
                                        :renduid="<?php echo e($rendu->id); ?>"
                                        :oldnote="<?php echo e($rendu->note); ?>"
                                        oldcommentaire="<?php echo e($rendu->commentaire); ?>"
                                        :etudiantid="<?php echo e($rendu->user_id); ?>">
                                    </update-note-component>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/prof/devoir/show.blade.php */ ?>