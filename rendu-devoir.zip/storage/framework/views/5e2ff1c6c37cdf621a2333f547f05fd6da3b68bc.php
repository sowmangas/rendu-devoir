<?php $__env->startSection('homeContent'); ?>
    <form action="<?php echo e(route('admin.formations.update', $formation)); ?>" method="post">
        <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


        <div class="form-group">
            <label for="nom_formation">NOM FORMATION</label>
            <input name="nom_formation" id="nom_formation" type="text" class="form-control<?php echo e($errors->has('nom_formation') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e($errors->has('nom_formation') ? old('nom_formation') : $formation->nom_formation); ?>">
            <?php if($errors->has('nom_formation')): ?>
                <small class="text-danger"><?php echo e($errors->first('nom_formation')); ?></small>
            <?php endif; ?>
        </div>


        <div class="form-group">
            <button class="btn btn-primary">Soumettre</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/formation/edit.blade.php ENDPATH**/ ?>