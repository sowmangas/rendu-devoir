<header id="header">
    <section class="wrap-top clearfix">
        <div class="container">
            <ul class="list-inline  mobile-hide list-social">
                <li><a href="https://www.facebook.com/Univ.de.Picardie.JV" class="social-btn-top"> <i class="fa fa-facebook"></i> </a></li>
                <li><a href="https://twitter.com/upjv" class="social-btn-top"> <i class="fa fa-twitter"></i> </a></li>
                <li><a href="https://www.youtube.com/channel/UCcCH6ab3DzjUJTGSxjfeiXQ" class="social-btn-top"> <i class="fa fa-youtube"></i> </a></li>
            </ul>

            <ul class="list-inline list-contact">
                <li><i class="fa fa-sitemap"></i> &nbsp http://www.rendudevoir-upicardie.com</li>
            </ul>
        </div>
    </section>

    <!-- container start -->
    <div class="container">

        <div class="row">
            <div class="col-sm-4">
                <?php if (\Illuminate\Support\Facades\Blade::check('granted', \App\Enum\UserRole::ADMIN)): ?>
                <!-- brand -->
                <a class="brand" href="<?php echo e(route('admin.users.index')); ?>">
                    <img src="https://extra.u-picardie.fr/moodle/upjv/pluginfile.php/1/core_admin/logocompact/0x70/1553712355/Logo_UPJV_navbar.png" class="logo" title="Site logo"/>
                    <div class="logo-text-wrap">
                        <h1 class="sitename"><?php echo e(env('APP_NAME')); ?></h1>

                    </div>
                </a>
                <!-- brand// -->
                <?php else: ?>
                <!-- brand -->
                <a class="brand" href="<?php echo e(url('/home')); ?>">
                    <img src="https://extra.u-picardie.fr/moodle/upjv/pluginfile.php/1/core_admin/logocompact/0x70/1553712355/Logo_UPJV_navbar.png" class="logo" title="Site logo"/>
                    <div class="logo-text-wrap">
                        <h1 class="sitename"><?php echo e(env('APP_NAME')); ?></h1>

                    </div>
                </a>
                <!-- brand// -->
                <?php endif; ?>
            </div>

            <div class="col-sm-8">

                <!-- navbar -->
                <nav id="navbar" class="navbar navbar-default pull-right" role="navigation">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse"
                                data-target="#navbar-collapse-1">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <!--  <a class="navbar-brand" href="#">Home</a> -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                            <?php if (\Illuminate\Support\Facades\Blade::check('granted', \App\Enum\UserRole::PROF)): ?>
                            <li class="<?php echo e(setActiveRoot('prof.devoirs.create')); ?>">

                                <a href="<?php echo e(route('prof.devoirs.create')); ?>"><?php echo e(__('Création d\'un devoir')); ?></a>

                            </li>
                            <?php endif; ?>

                            
                            <?php if(auth()->guard()->guest()): ?>
                                <li class="<?php echo e(setActiveRoot('login')); ?>">
                                    <a href="<?php echo e(route('login')); ?>">
                                        <?php echo e(__('Login')); ?>

                                    </a>
                                </li>
                            <?php else: ?>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                        <?php echo e(Auth::user()->nom); ?> <?php echo e(Auth::user()->role); ?>

                                        <b class="caret"></b>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                                <?php echo e(__('Déconnexion')); ?>

                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                            
                        </ul>


























                    </div><!-- /.navbar-collapse -->
                </nav><!-- navbar // -->
            </div><!-- col //  -->
        </div><!-- row //  -->
    </div><!-- container //  -->
</header>
<!-- header //  -->
<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/layouts/new/header.blade.php ENDPATH**/ ?>