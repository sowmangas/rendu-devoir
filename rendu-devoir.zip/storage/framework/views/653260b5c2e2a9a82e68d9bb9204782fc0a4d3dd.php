<?php $__env->startSection('homeContent'); ?>
    <h6><a href="<?php echo e(route('admin.formations.create')); ?>" class="btn btn-primary">Création d'une formation</a></h6>
    <table class="table table-sm table-hover">
        <thead>
        <tr>
            <td class="text-center">Nom Formation</td>
            <td class="text-center">Nombre d'étudiants</td>
            <td class="text-center">Liste d'étudiants</td>
            <td class="text-center">Modification</td>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($formation->nom_formation); ?> </td>
                <td>
                        <?php echo e($formation->users_count); ?>


                </td>
                <td>
                    <form action="<?php echo e(route('admin.users.list', $formation->id)); ?>" method="post">
                        <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>

                        <div class="form-group">
                            <button class="btn btn-primary">Afficher</button>
                        </div>

                    </form>
                </td>
                <td>
                    <a href="<?php echo e(route('admin.formations.edit', $formation)); ?>" class="btn btn-primary">
                        <i class="fa fa-edit"></i>
                    </a>
                </td>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/formation/index.blade.php ENDPATH**/ ?>