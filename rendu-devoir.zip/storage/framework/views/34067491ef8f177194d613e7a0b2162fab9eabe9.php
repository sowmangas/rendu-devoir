<?php echo e($slot); ?>

<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>