<?php $__env->startSection('homeContent'); ?>
    <h6><a href="<?php echo e(route('admin.matiere.create')); ?>" class="btn btn-primary">Création d'une matière</a></h6>
    <table class="table table-sm table-hover">
        <thead>
        <tr>
            <td class="text-center">Matière</td>
            <td class="text-center">Modification</td>
            <td class="text-center" colspan="2">Actions</td>
        </tr>
        </thead>

        <tbody>
        <?php $__currentLoopData = $matieres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matiere): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td><?php echo e($matiere->nom_matiere); ?> </td>
                <td>
                    <a href="<?php echo e(route('admin.matiere.edit', $matiere)); ?>" class="btn btn-primary">
                        <i class="fa fa-edit"></i>
                    </a>
                </td>
                <td>
                        <form method="post" action="<?php echo e(route('admin.matiere.destroy', $matiere)); ?>">
                            <?php echo csrf_field(); ?> <?php echo e(method_field('delete')); ?>

                            <button type="submit" class="btn btn-danger" title="Supprimer la matiere">
                                <i class="fa fa-trash"></i>
                            </button>
                        </form>


                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/matiere/index.blade.php ENDPATH**/ ?>