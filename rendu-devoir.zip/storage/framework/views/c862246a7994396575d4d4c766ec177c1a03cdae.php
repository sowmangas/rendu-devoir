<?php $__env->startSection('homeContent'); ?>
    <register-component url="<?php echo e(route('register')); ?>"></register-component>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/users/create.blade.php ENDPATH**/ ?>