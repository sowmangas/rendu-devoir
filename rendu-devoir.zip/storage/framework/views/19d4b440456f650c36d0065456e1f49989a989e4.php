<?php $__env->startSection('homeContent'); ?>
    <form action="<?php echo e(route('admin.users.update', $user)); ?>" method="post">
        <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


        <div class="form-group">
            <label for="adresse_mel">Adresse Mèl</label>
            <input name="adresse_mel" id="adresse_mel" type="text" class="form-control<?php echo e($errors->has('adresse_mel') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e($errors->has('adresse_mel') ? old('adresse_mel') : $user->adresse_mel); ?>">
            <?php if($errors->has('adresse_mel')): ?>
                <small class="text-danger"><?php echo e($errors->first('adresse_mel')); ?></small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="nom">NOM</label>
            <input name="nom" id="nom" type="text" class="form-control<?php echo e($errors->has('nom') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e($errors->has('nom') ? old('nom') : $user->nom); ?>">
            <?php if($errors->has('nom')): ?>
                <small class="text-danger"><?php echo e($errors->first('nom')); ?></small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="prenom">PRENOM</label>
            <input name="prenom" id="prenom" type="text" class="form-control<?php echo e($errors->has('prenom') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e(old('prenom') ?? $user->prenom); ?>">
            <?php if($errors->has('prenom')): ?>
                <small class="text-danger"><?php echo e($errors->first('prenom')); ?></small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="role">ROLE</label>
            <select name="role" id="role" class="form-control<?php echo e($errors->has('role') ? ' is-invalid' : ''); ?>">
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($role == $user->role ? 'selected' : ''); ?> value="<?php echo e($role); ?>">
                        <?php echo e($role); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="form-group">
            <label for="titre">TITRE</label>
            <input name="titre" id="titre" type="text" class="form-control<?php echo e($errors->has('titre') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e(old('titre') ?? $user->titre); ?>">
            <?php if($errors->has('titre')): ?>
                <small class="text-danger"><?php echo e($errors->first('titre')); ?></small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label for="formation_id">FORMATION</label>
            <select name="formation_id" id="formation_id" class="form-control<?php echo e($errors->has('formation_id') ? ' is-invalid' : ''); ?>">
                <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($formation->id == $user->formation_id ? 'selected' : ''); ?> value="<?php echo e($formation->id); ?>">
                        <?php echo e($formation->nom_formation); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php if($errors->has('formation_id')): ?>
                <small class="text-danger"><?php echo e($errors->first('formation_id')); ?></small>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <button class="btn btn-primary">Soumettre</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>