<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($title . ' - ' . env('APP_NAME')); ?></title>

    <?php $__env->startSection('vue'); ?>
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <?php echo $__env->yieldSection(); ?>

    <?php $__env->startSection('css'); ?>

        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/icons/tn_favicon.jpg')); ?>"/>


        <script src="<?php echo e(asset('template/js/jquery-2.0.0.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('template/js/script.js')); ?>" type="text/javascript"></script>

        <!-- bootstrap -->
        <link href="<?php echo e(asset('template/bootstrap/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css"/>
        <script src="<?php echo e(asset('template/bootstrap/js/bootstrap.min.js')); ?>" type="text/javascript"></script>

        <!-- font awesome -->
        <link href="<?php echo e(asset('template/fonts/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css"/>

        <!-- Owl slider -->
        <link rel="stylesheet" href="<?php echo e(asset('tempalte/plugins/owl-carousel/owl.carousel.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('tempalte/plugins/owl-carousel/owl-theme.min.css')); ?>">
        <script src="<?php echo e(asset('template/plugins/owl-carousel/owl.carousel.js')); ?>"></script>
        <script src="<?php echo e(asset('template/plugins/owl-carousel/plugin-setting.js')); ?>"></script>

        <!-- custom style -->
        <link href="<?php echo e(asset('template/css/mystyle.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('template/css/animate.css')); ?>" rel="stylesheet" type="text/css"/>
        <link href="<?php echo e(asset('template/css/responsive.css')); ?>" rel="stylesheet" media="only screen and (max-width: 1200px)"/>
    <?php echo $__env->yieldSection(); ?>
</head>
<body>

<div class="main-wrap" id="app">
    <?php echo $__env->make('layouts.new.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if(session('message')): ?>
        <div class="row">
            <div class="col-md-12">
                <div class="alert alert-<?php echo e(session('type')); ?>"><?php echo e(session('message')); ?></div>
            </div>
        </div>
    <?php endif; ?>

    <section class="wrap wrap-team">

        <div class="container">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

    </section>

    <?php echo $__env->make('layouts.new.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- main wrap finish -->
<a href="#top" class="topHome">
    <i class="fa fa-chevron-up fa-2x"></i>
</a>

<?php $__env->startSection('js'); ?>
<?php echo $__env->yieldSection(); ?>
</body>
</html>
<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/layouts/new/base.blade.php ENDPATH**/ ?>