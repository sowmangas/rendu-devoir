<?php $__env->startSection('homeContent'); ?>
    <form action="<?php echo e(route('admin.matiere.update', $matiere)); ?>" method="post">
        <?php echo csrf_field(); ?> <?php echo e(method_field('put')); ?>


        <div class="form-group">
            <label for="nom_matiere">NOM MATIERE</label>
            <input name="nom_matiere" id="nom_matiere" type="text" class="form-control<?php echo e($errors->has('nom_matiere') ? ' is-invalid' : ''); ?>"
                   value="<?php echo e($errors->has('nom_matiere') ? old('nom_matiere') : $matiere->nom_matiere); ?>">
            <?php if($errors->has('nom_matiere')): ?>
                <small class="text-danger"><?php echo e($errors->first('nom_matiere')); ?></small>
            <?php endif; ?>
        </div>


        <div class="form-group">
            <button class="btn btn-primary">Soumettre</button>
        </div>

    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('js'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/admin/matiere/edit.blade.php ENDPATH**/ ?>