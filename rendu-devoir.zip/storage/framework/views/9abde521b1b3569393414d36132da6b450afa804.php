<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-sm table-hover table">
                <thead>
                <tr>
                    <th class="text-center">Intitulé</th>
                    <th class="text-center">Période</th>
                    <th class="text-center">Evalué</th>
                    <th class="text-center">Type correction</th>
                    <th class="text-center">Date limite depot</th>
                    <th class="text-center">Enoncé</th>
                    <th class="text-center">Corrigé type</th>
                    <th class="text-center">Rendu</th>
                    <th class="text-center">Commentaire</th>
                    <th class="text-center">Note</th>
                </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="text-center">
                        <td><?php echo e($devoir->intitule); ?></td>
                        <td><?php echo e($devoir->periode); ?></td>
                        <td><?php echo e($devoir->evaluer); ?></td>
                        <td><?php echo e($devoir->type_correction); ?></td>
                        <td><?php echo e($devoir->date_limit_depot); ?></td>
                        <td>
                            <a href="<?php echo e($devoir->enonce); ?>" download="<?php echo e($devoir->enonce); ?>" class="btn btn-link">
                                <i class="fa fa-download"></i>
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e($devoir->corrige_type); ?>" download class="btn btn-link" title="Télécharger le corrigé" <?php echo e(!$devoir->visible_corrige_type ? 'hidden' : ''); ?>>
                                <i class="fa fa-download"></i>
                            </a>
                        </td>
                        <td>
                            <?php if($devoir->rendu): ?>
                                <a href="<?php echo e(asset($devoir->rendu)); ?>" download class="btn btn-link" title="Téléchargé le rendu">
                                    <i class="fa fa-download"></i>
                                </a>
                            <?php else: ?>
                            <form action="<?php echo e(route('etudiant.rendus.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row pull-right">
                                    <div class="col-md-6">
                                        <label for="rendu" class="sr-only">Rendu</label>
                                        <input type="file" name="rendu" id="rendu" class="form-control-sm form-control<?php echo e($errors->has('rendu') ? ' is-invalid' : ''); ?>">
                                        <input type="hidden" name="devoir_id" id="devoir_id" value="<?php echo e($devoir->id); ?>">

                                        <?php if($errors->has('rendu')): ?>
                                            <div class="alert alert-danger"><?php echo e($errors->first('rendu')); ?></div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="col-md-6">
                                        <button type="submit" class="btn btn-default btn-sm">Soumettre</button>
                                    </div>
                                </div>
                            </form>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($devoir->commentaire); ?></td>
                        <td><?php echo e($devoir->note); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/etudiant/devoirs/show.blade.php ENDPATH**/ ?>