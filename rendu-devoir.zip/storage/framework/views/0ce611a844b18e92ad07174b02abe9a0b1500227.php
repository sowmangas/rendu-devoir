<?php $__env->startComponent('mail::message'); ?>
# Bonjour <?php echo e(Auth::user()->prenom); ?> <?php echo e(Auth::user()->nom); ?>


<?php $__env->startComponent('mail::button', ['url' => url('home')]); ?>
Vous avez deposé le devoir <?php echo e($rendu->devoir->intitule); ?> de la matière  <?php echo e($rendu->devoir->nom_matiere); ?> avec succès.
<?php echo $__env->renderComponent(); ?>

Cordialement!<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/emails/etudiant/devoir_rendu.blade.php ENDPATH**/ ?>