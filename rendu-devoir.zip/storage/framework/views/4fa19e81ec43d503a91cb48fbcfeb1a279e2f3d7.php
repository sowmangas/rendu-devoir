<?php $__env->startComponent('mail::message'); ?>
# Bonjour <?php echo e($prof->prenom); ?> <?php echo e($prof->nom); ?>

<?php $__env->startComponent('mail::button', ['url' => url('home')]); ?>
Un devoir vient d'être rendu pour <?php echo e($rendu->devoir->intitule); ?> de la matière  <?php echo e($rendu->devoir->nom_matiere); ?>.
<?php echo $__env->renderComponent(); ?>

Cordialement!<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/emails/prof/prof_rendu.blade.php ENDPATH**/ ?>