<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <table class="table table-sm table-hover">
                <thead>
                <tr>
                    <th class="text-center">Intitulé</th>
                    <th class="text-center">Période</th>
                    <th class="text-center">Corrigé type</th>
                    <th class="text-center">Nom matière</th>
                    <th class="text-center">Enoncé</th>
                    <th class="text-center">Date limite</th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center">
                            <a href="<?php echo e(route('prof.devoirs.show', $devoir)); ?>">
                                <?php echo e($devoir->intitule); ?>

                            </a>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(route('prof.devoirs.show', $devoir)); ?>">
                                <?php echo e($devoir->periode); ?>

                            </a>
                        </td>
                        <?php if($devoir->type_correction): ?>
                            <td class="text-center">
                                <a href="<?php echo e($devoir->corrige_type); ?>" download class="btn btn-link"
                                   title="Téléchargé le corrigé type">
                                    <i class="fa fa-download"></i>
                                </a>
                            </td>
                        <?php endif; ?>
                        <td class="text-center">
                            <a href="<?php echo e(route('prof.devoirs.show', $devoir)); ?>">
                                <?php echo e($devoir->nom_matiere); ?>

                            </a>
                        </td>
                        <td class="text-center">
                            <a href="<?php echo e(asset($devoir->enonce)); ?>" download class="btn btn-link"
                               title="Téléchargé l'énonce">
                                <i class="fa fa-download"></i>
                            </a>
                        </td>
                        <td class="text-center"><?php echo e($devoir->date_limit_depot->format('d/m/Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('vue'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    ##parent-placeholder-93f8bb0eb2c659b85694486c41717eaf0fe23cd4##

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\Spectre360\Documents\Cours\rendu-devoir\resources\views/prof/devoir/matiere.blade.php */ ?>