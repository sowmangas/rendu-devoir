<?php

namespace App\Enum;

abstract class ModificationNoteStatus
{
    const OK = "ok";
    const PENDING = "pending";
    const REJECTED = "rejected";
}
