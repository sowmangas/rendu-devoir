<?php

namespace App\Enum;

abstract class StatusUser
{
    const LOCKED = "locked";
    const UNLOCKED = "unlocked";
}
