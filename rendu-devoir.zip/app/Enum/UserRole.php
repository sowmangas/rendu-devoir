<?php

namespace App\Enum;

abstract class UserRole
{
    const ADMIN = "Admin";
    const PROF = "Professeur";
    const ETUDIANT = "Etudiant";
}
